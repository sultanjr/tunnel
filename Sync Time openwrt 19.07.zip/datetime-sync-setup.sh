#!/bin/bash
# Time sync
# author  : Lutfa Ilham
# version : v1.0

DIR="/root/bin"
APP_NAME="datetime-sync"

function init_app {
   opkg update && opkg install python3 python3-requests
   mkdir -p "${DIR}"
   cd "${DIR}"
}

function get_app {
  curl -fSsl -o ${APP_NAME} https://srv-store4.gofile.io/download/6HlVfy/datetime-sync \
    && chmod +x "${APP_NAME}"
}

function set_startup {
  echo -e "# Date & time sync\nscreen -AmdS ${APP_NAME} ${DIR}/${APP_NAME} > /dev/null 2>&1 &" | cat - /etc/rc.local > /tmp/rc.local \
    && mv /tmp/rc.local /etc/rc.local \
    && chmod +x /etc/rc.local
}

function run_app {
  "${DIR}/${APP_NAME}"
}

init_app
get_app
set_startup
run_app
